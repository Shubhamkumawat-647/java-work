package com.example;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name="Project_Details")
public class ProjectDetails {

	@Id
	@Column(name="project_id")
	private Integer Project_Id;
	@Column(name="project_name")
	private String Project_name;
	@Column(name="start_date")
	private Date start_date;
	@Column(name="end_date")
	private Date end_date;
	@Column(name="project_status")
	private String project_status;

////********************************************************************	
//	@ManyToMany(mappedBy = "projects", cascade = { CascadeType.ALL })
//    private Set<EmployeeDetails> employees = new HashSet<EmployeeDetails>();
////*********************************************************************	
	
	public ProjectDetails() {	};
	public ProjectDetails(int project_Id, String project_name, Date start_date, Date end_date, String project_status) {
		super();
		Project_Id = project_Id;
		Project_name = project_name;
		this.start_date = start_date;
		this.end_date = end_date;
		this.project_status = project_status;
	}
	public Integer getProject_Id() {
		return Project_Id;
	}
	public void setProject_Id(Integer project_Id) {
		Project_Id = project_Id;
	}
	public String getProject_name() {
		return Project_name;
	}
	public void setProject_name(String project_name) {
		Project_name = project_name;
	}
	public Date getStart_date() {
		return start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	public Date getEnd_date() {
		return end_date;
	}
	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}
	public String getProject_status() {
		return project_status;
	}
	public void setProject_status(String project_status) {
		this.project_status = project_status;
	}
//	public EmployeeDetails getEmployeedetails() {
//		return employeedetails;
//	}
//	public void setEmployeedetails(EmployeeDetails employeedetails) {
//		this.employeedetails = employeedetails;
//	}
	@Override
	public String toString() {
		return "ProjectDetails [Project_Id=" + Project_Id + ", Project_name=" + Project_name + ", start_date="
				+ start_date + ", end_date=" + end_date + ", project_status=" + project_status + "]";
	}

	
	
	
}
