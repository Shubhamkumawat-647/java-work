package com.example;

import java.text.ParseException;
import java.util.List;


public interface TimesheetService {
	List<Timesheet> getAllTimesheet() throws ParseException;
	String addTimesheet(Timesheet timesheet) throws ParseException;
	Timesheet getTimesheet(Integer timesheet_Id) throws ParseException;
	String updateTimesheet(Integer timesheet_Id, Timesheet timesheet) throws ParseException;
	String deleteTimesheet(Integer timesheet_Id) throws ParseException;


}
