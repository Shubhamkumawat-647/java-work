package com.example;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api/timesheet")
public class TimesheetController {

	@Autowired
	TimesheetService timesheetService;
	
	@GetMapping("/getall")
	public List<Timesheet> getAllTimesheet() throws ParseException {
		return timesheetService.getAllTimesheet();
	}
	
	@PostMapping("/post")
	public ResponseEntity<String> addTimesheet(@RequestBody Timesheet Timesheet) throws ParseException{
		String emp=timesheetService.addTimesheet(Timesheet);
		return new ResponseEntity<String>(emp,HttpStatus.OK);
		
	}
	
	@GetMapping("/get")
	public Timesheet getTimesheet(@RequestParam Integer project_Id) throws ParseException{
		return timesheetService.getTimesheet(project_Id);
	}
	
	@PutMapping("/update")
	public String updateTimesheet(@RequestParam Integer employee_Id,@RequestBody Timesheet Timesheet) throws ParseException{
		return timesheetService.updateTimesheet(employee_Id, Timesheet);
	}
	
	@DeleteMapping("/delete")
	public String deleteTimesheet(@RequestParam Integer employee_Id) throws ParseException{
		return timesheetService.deleteTimesheet(employee_Id);
	}
}
