package com.example;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DeptRepositiory extends JpaRepository<Deparment, Integer> {

}
