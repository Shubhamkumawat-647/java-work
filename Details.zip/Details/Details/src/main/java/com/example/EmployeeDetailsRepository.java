package com.example;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeDetailsRepository extends CrudRepository<EmployeeDetails, Integer>{
	
	@Query("SELECT Count(i) FROM EmployeeDetails i" )
	Integer FindAllQuery();
	
	@Query("select e from EmployeeDetails e where e.employeeId=:id")
	List<EmployeeDetails> findById(int id);
	
	@Query("select e from EmployeeDetails e where e.emailId=:emailid")
	List<EmployeeDetails> findByEmailId(String emailid);

	//********************************************************************

	  @Query(value = "SELECT e FROM EmployeeDetails e  WHERE e.firstName LIKE 's%'")
	  List<EmployeeDetails> findByNameLike();


//	  @Transactional
//	  @Modifying
//	  @Query(value = "UPDATE tutorials SET published=true WHERE id=?1", nativeQuery = true)
//	  int publishTutorial(Long id);

//****************************************************************************************************

	  
//Inner--Right********************************************************************************************
	  
	  @Query("select e.firstName,d.deptCode from EmployeeDetails e INNER JOIN e.dept as d")
		List<Object[]> getEmpAndDeptInnerJoinData();

		// ***********Getting Right table row data and Left table connected row data

		@Query("select e.emailId,d.deptCode from EmployeeDetails e RIGHT JOIN e.dept as d")
		List<Object[]> getEmpAndDeptRightJoinData();

		// ***********Getting Left table data and Right table connected row data

//		@Query("select e.firstName,d.deptCode from EmployeeDetails e LEFT JOIN e.dept as d where e.empSal>=:sal")
//		List<Object[]> getEmpAndDeptLeftJoinData2(double sal);

// *********************Getting Only Parent table row Data*****************

		@Query("select e.firstName from EmployeeDetails e LEFT JOIN e.dept d where d IS NULL")
		List<Object[]> getPareentSideDataUsingLeftJoin();

		@Query("select e from EmployeeDetails e LEFT JOIN e.dept d where d IS NULL")
		List<Object[]> getPareentSideRecordUsingLeftJoin();

//join 4 table ************************************************************************************************************
		@Query("select e.firstName,d.deptCode,p.Project_name,t.workingHours from EmployeeDetails e INNER JOIN e.dept as d INNER JOIN e.proj as p INNER JOIN e.timesheet as t where d.deptId =:deptID")
		List<Object[]> findBydeptID1(int deptID);
		
//*****************************************************************************************
		@Query("select e.firstName,d.deptCode from EmployeeDetails e LEFT JOIN e.dept as d where d.deptId =:deptID")
		List<Object[]> getEmpAndDeptLeftJoinData2(int deptID);

}
