package com.example;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProjectDetailsServiceImpl implements ProjectDetailsService{

	@Autowired
	private ProjectDetailsRepository projectDetailsRepository;
	
	
	@Override
	public List<ProjectDetails> getAllProjectDetails() throws ParseException {
		List<ProjectDetails> projects=(List<ProjectDetails>) projectDetailsRepository.findAll();
		return projects;
	}


	@Override
	public String addProjectDetails(ProjectDetails projectDetails) throws ParseException {
		projectDetailsRepository.save(projectDetails);
		return "Project Details Saved";
	}


	@Override
	public ProjectDetails getProjectDetails(Integer project_Id) throws ParseException {
		Optional<ProjectDetails> project=projectDetailsRepository.findById(project_Id);
		return project.get();
	}


	@Override
	public String updateProjectDetails(Integer project_Id, ProjectDetails projectDetails) throws ParseException {
		Optional<ProjectDetails> project=projectDetailsRepository.findById(project_Id);
		
		project.get().setEnd_date(projectDetails.getEnd_date());
		project.get().setProject_name(projectDetails.getProject_name());
		project.get().setProject_status(projectDetails.getProject_status());
		project.get().setStart_date(projectDetails.getStart_date());
		
		projectDetailsRepository.save(project.get());
		return "Project Details Updated";

	}
	@Override
	public String deleteProjectDetails(Integer project_Id) throws ParseException {
		// TODO Auto-generated method stub
		projectDetailsRepository.deleteById(project_Id);
		return "Project Details updated";
		
	}


	@Override
	public Integer getallprojectcount() throws ParseException {
		ArrayList<ProjectDetails> projectCount=new ArrayList<>();
		projectCount.addAll(getAllProjectDetails());
		int count=projectCount.size();
		
		return count;
	}
	@Override
	public  Integer FindAllQuery() {
	    return projectDetailsRepository.FindAllQuery();

	}
	
	
	
}
