package com.example;

import java.text.ParseException;
import java.util.List;

public interface EmployeeDetailsService {

	List<EmployeeDetails> getAllEmployeeDetails() throws ParseException;
	Integer addEmployeeDetails(EmployeeDetails employeedetails) throws ParseException;
	EmployeeDetails getEmployeeDetails(Integer employeeId) throws ParseException;
	void editEmployeeDetails(Integer employeeId,EmployeeDetails employeedetails) throws ParseException;
	void deleteEmployeeDetails(Integer employeeId) throws ParseException;
	
	
	
	
	Integer FindAllQuery();
	
	List<EmployeeDetails> findById(int id)throws ParseException;
	
	List<EmployeeDetails> findByEmailId(String emailid)throws ParseException;
	List<EmployeeDetails> findByNameLike()throws ParseException;
	
	List<Object[]> getEmpAndDeptInnerJoinData()throws ParseException;
	List<Object[]> getEmpAndDeptRightJoinData()throws ParseException;
	
	List<Object[]> getPareentSideDataUsingLeftJoin()throws ParseException;
	List<Object[]> getPareentSideRecordUsingLeftJoin()throws ParseException;
	
	List<Object[]> findBydeptID1(int deptID)throws ParseException;
	
	List<Object[]> getEmpAndDeptLeftJoinData2(int deptID) throws ParseException;
}
 