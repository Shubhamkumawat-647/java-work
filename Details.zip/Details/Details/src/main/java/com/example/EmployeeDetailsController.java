package com.example;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/employeedetails")
public class EmployeeDetailsController {

	@Autowired
	 EmployeeDetailsService empDetailsService;
	@GetMapping("/getall")
	public List<EmployeeDetails> getAllEmployeeDetails() throws ParseException{
		return empDetailsService.getAllEmployeeDetails();
	}
	@PostMapping("/post")
	public ResponseEntity<Integer>addEmployee(@RequestBody EmployeeDetails employeedetails) throws ParseException{
		Integer empId=empDetailsService.addEmployeeDetails(employeedetails);
		return new ResponseEntity<Integer>(empId,HttpStatus.OK);
	}
	
	@GetMapping("/get")
	public ResponseEntity<EmployeeDetails> getEmployeeDetail(@RequestParam Integer employeeId) throws ParseException{
	EmployeeDetails empdetails=empDetailsService.getEmployeeDetails(employeeId);
	return new ResponseEntity<EmployeeDetails>(empdetails,HttpStatus.OK);
}
	
	@PutMapping("/update")
	public void editEmployeeDetails(@RequestParam Integer employeeId,@RequestBody EmployeeDetails employeedetails) throws ParseException {
		empDetailsService.editEmployeeDetails(employeeId, employeedetails);
	}
	
	@DeleteMapping("/delete")
	public void deleteEmployeeDetails(@RequestParam Integer employeeId) throws ParseException{
		empDetailsService.deleteEmployeeDetails(employeeId);
	}
	
	
	@GetMapping(path = {"/get/v2"})
	public  Integer FindAllQuery() {
	    return empDetailsService.FindAllQuery();
	}
	
	@GetMapping(path = {"/get{id}"})
	public List<EmployeeDetails> findById(int id) throws ParseException {
	    return empDetailsService.findById(id);
	}
	
	@GetMapping(path = {"/get1{emailId}"})
	public List<EmployeeDetails> findByEmailId(String emailid) throws ParseException {
	    return empDetailsService.findByEmailId(emailid);
	}
	//**************************************************************************************
	@GetMapping(path = {"/getBynamelike"})
	public List<EmployeeDetails>findByNameLike() throws ParseException {
	    return empDetailsService.findByNameLike();
	}
	
	@GetMapping(path = {"/getEmpAndDeptInnerJoinData"})
	public List<Object[]> getEmpAndDeptInnerJoinData() throws ParseException {
	    return empDetailsService.getEmpAndDeptInnerJoinData();
	}
	
	@GetMapping(path = {"/getEmpAndDeptRightJoinData"})
	public List<Object[]> getEmpAndDeptRightJoinData() throws ParseException {
	    return empDetailsService.getEmpAndDeptRightJoinData();
	}
	
	@GetMapping(path = {"/getPareentSideDataUsingLeftJoin"})
	public List<Object[]> getPareentSideDataUsingLeftJoin() throws ParseException {
	    return empDetailsService.getPareentSideDataUsingLeftJoin();
	}
	
	@GetMapping(path = {"/getPareentSideRecordUsingLeftJoin"})
	public List<Object[]> getPareentSideRecordUsingLeftJoin() throws ParseException {
	    return empDetailsService.getPareentSideRecordUsingLeftJoin();
	}
	
	@GetMapping(path = {"/findBydeptID1{deptID}"})
	public List<Object[]> findBydeptID1(int deptID) throws ParseException {
	    return empDetailsService.findBydeptID1(deptID);
	}
	
	@GetMapping(path = {"/getEmpAndDeptLeftJoinData2{deptID}"})
	public List<Object[]> getEmpAndDeptLeftJoinData2(int deptID) throws ParseException {
	    return empDetailsService.getEmpAndDeptLeftJoinData2(deptID);
	}
}
