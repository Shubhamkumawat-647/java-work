package com.example;

import java.text.ParseException;
import java.util.List;

public interface ProjectDetailsService {

	List<ProjectDetails> getAllProjectDetails() throws ParseException;
	String addProjectDetails(ProjectDetails projectDetails) throws ParseException;
	ProjectDetails getProjectDetails(Integer project_Id) throws ParseException;
	String updateProjectDetails(Integer project_Id, ProjectDetails projectDetails) throws ParseException;
	String deleteProjectDetails(Integer project_Id) throws ParseException;
	Integer getallprojectcount() throws ParseException;
	
	Integer FindAllQuery();
}
