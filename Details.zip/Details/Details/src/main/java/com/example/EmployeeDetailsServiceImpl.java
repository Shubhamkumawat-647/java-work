package com.example;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public class EmployeeDetailsServiceImpl implements EmployeeDetailsService{

	@Autowired
	private EmployeeDetailsRepository employeeDetailsRepository;
	@Override
	public List<EmployeeDetails> getAllEmployeeDetails() throws ParseException {
		List<EmployeeDetails> empDetailsList=(List<EmployeeDetails>) employeeDetailsRepository.findAll();
		return empDetailsList;
	}
	@Override
	public Integer addEmployeeDetails(@RequestBody EmployeeDetails employeedetails) throws ParseException {
		
		Timesheet timesheet=new Timesheet();
		timesheet.setDate(employeedetails.getTimesheet().getDate());
		timesheet.setEmployeedetails(employeedetails.getTimesheet().getEmployeedetails());
		timesheet.setLeavetype(employeedetails.getTimesheet().getLeavetype());
		timesheet.setOvertime(employeedetails.getTimesheet().getOvertime());
		timesheet.setWorkingHours(employeedetails.getTimesheet().getWorkingHours());
		timesheet.setTimesheet_id(employeedetails.getTimesheet().getTimesheet_id());
		employeedetails.setTimesheet(timesheet);
		
//
//		ProjectDetails projectdetails=new ProjectDetails();
//		projectdetails.setProject_name(employeedetails.getProjectdetails().getProject_name());
//		projectdetails.setProject_Id(employeedetails.getProjectdetails().getProject_Id());
//		projectdetails.setStart_date(employeedetails.getProjectdetails().getStart_date());
//		projectdetails.setEnd_date(employeedetails.getProjectdetails().getEnd_date());
//		projectdetails.setProject_status(employeedetails.getProjectdetails().getProject_status());
//		employeedetails.setProjectdetails(projectdetails);
		
		employeeDetailsRepository.save(employeedetails);
		return 0;
	}
	@Override
	public EmployeeDetails getEmployeeDetails(Integer employeeId) throws ParseException {
		Optional<EmployeeDetails> optional=employeeDetailsRepository.findById(employeeId);
		return optional.get();
	}
	@Override
	public void editEmployeeDetails(Integer employeeId, EmployeeDetails employeedetails) throws ParseException {
		// TODO Auto-generated method stub
		
		Optional<EmployeeDetails> emp=employeeDetailsRepository.findById(employeeId);
		emp.get().setDesignation(employeedetails.getDesignation());
		emp.get().setEmailId(employeedetails.getEmailId());
		emp.get().setEmployeeType(employeedetails.getEmployeeType());
		emp.get().setEmpStatus(employeedetails.getEmpStatus());
	//	emp.get().setEmployeeId(employeedetails.getEmployeeId());
		emp.get().setEnddate(employeedetails.getEnddate());
		emp.get().setFirstName(employeedetails.getFirstName());
		emp.get().setGrade(employeedetails.getGrade());
		emp.get().setLastName(employeedetails.getLastName());
		emp.get().setPassword(employeedetails.getPassword());
		emp.get().setStartDate(employeedetails.getStartDate());
		
		
		
		Timesheet timesheet=employeedetails.getTimesheet();
		timesheet.setDate(employeedetails.getTimesheet().getDate());
		timesheet.setEmployeedetails(employeedetails.getTimesheet().getEmployeedetails());
		timesheet.setLeavetype(employeedetails.getTimesheet().getLeavetype());
		timesheet.setOvertime(employeedetails.getTimesheet().getLeavetype());
		timesheet.setWorkingHours(employeedetails.getTimesheet().getWorkingHours());
		
//		ProjectDetails projectdetails=employeedetails.getProjectdetails();
		
//		projectdetails.setProject_name(employeedetails.getProjectdetails().getProject_name());
//		projectdetails.setProject_Id(employeedetails.getProjectdetails().getProject_Id());
//		projectdetails.setStart_date(employeedetails.getProjectdetails().getStart_date());
//		projectdetails.setEnd_date(employeedetails.getProjectdetails().getEnd_date());
//		projectdetails.setProject_status(employeedetails.getProjectdetails().getProject_status());		
		emp.get().setTimesheet(employeedetails.getTimesheet());
		
//		emp.get().setProjectdetails(employeedetails.getProjectdetails());
		//employeedetails.setProjectdetails(projectdetails);
		
		employeeDetailsRepository.save(emp.get());
		
		System.out.println("Employee Records Updated");
		
		
	}
	@Override
	public void deleteEmployeeDetails(Integer employeeId) throws ParseException {
		// TODO Auto-generated method stub
		employeeDetailsRepository.deleteById(employeeId);
		System.out.println("Employee with id "+employeeId+" deleted");
		
	}
	@Override
	public  Integer FindAllQuery() {
	    return employeeDetailsRepository.FindAllQuery();

	}
	@Override
	public List<EmployeeDetails> findById(int id) throws ParseException {
		
		return employeeDetailsRepository.findById(id);
	}
	@Override
	public List<EmployeeDetails> findByEmailId(String emailid) throws ParseException {
		return employeeDetailsRepository.findByEmailId(emailid);
	}
	@Override
	public List<EmployeeDetails> findByNameLike() throws ParseException {
		return employeeDetailsRepository.findByNameLike();
	}
	@Override
	public List<Object[]> getEmpAndDeptInnerJoinData() throws ParseException {
		
		return employeeDetailsRepository.getEmpAndDeptInnerJoinData();
	}
	@Override
	public List<Object[]> getEmpAndDeptRightJoinData() throws ParseException {
		
		return employeeDetailsRepository.getEmpAndDeptRightJoinData();
	}
	
	
	
	@Override
	public List<Object[]> getPareentSideDataUsingLeftJoin() throws ParseException {
		
		return employeeDetailsRepository.getPareentSideDataUsingLeftJoin();
	}
	@Override
	public List<Object[]> getPareentSideRecordUsingLeftJoin() throws ParseException {
		
		return employeeDetailsRepository.getPareentSideRecordUsingLeftJoin();
	}
	
	@Override
	public List<Object[]> findBydeptID1(int deptID) throws ParseException {
		return employeeDetailsRepository.findBydeptID1(deptID);
	}
	
	@Override
	public List<Object[]> getEmpAndDeptLeftJoinData2(int deptID) throws ParseException {
		
		return employeeDetailsRepository.getEmpAndDeptLeftJoinData2(deptID);
	}
	


	
}
