package com.example;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TimesheetServiceImpl implements TimesheetService{

	@Autowired
	private TimesheetRepository timesheetRepository;

	@Override
	public List<Timesheet> getAllTimesheet() throws ParseException {
		List<Timesheet> timesheet=(List<Timesheet>) timesheetRepository.findAll();
		return timesheet;
	}

	@Override
	public String addTimesheet(Timesheet timesheet) throws ParseException {
		timesheetRepository.save(timesheet);
		return "Tiesheet Details Saved";
	}

	@Override
	public Timesheet getTimesheet(Integer timesheet_Id) throws ParseException {
		Optional<Timesheet> timesheet=timesheetRepository.findById(timesheet_Id);
		return timesheet.get();
	}

	@Override
	public String updateTimesheet(Integer timesheet_Id, Timesheet timesheet) throws ParseException {
		Optional<Timesheet> timesheetup=timesheetRepository.findById(timesheet_Id);
		
		timesheetup.get().setDate(timesheet.getDate());
		timesheetup.get().setEmployeedetails(timesheet.getEmployeedetails());
		timesheetup.get().setLeavetype(timesheet.getLeavetype());
		timesheetup.get().setOvertime(timesheet.getOvertime());
		timesheetup.get().setWorkingHours(timesheet.getWorkingHours());
		
		timesheetRepository.save(timesheetup.get());
		return "Timesheet Details Updated";
	}

	@Override
	public String deleteTimesheet(Integer timesheet_Id) throws ParseException {
		timesheetRepository.deleteById(timesheet_Id);
		return "Timesheet Details deleted";
	}
		
	
}
