package com.example;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;


@Entity
@Table(name="employeeDetails")
public class EmployeeDetails {

	@Id
	@Column(name="eid")
	private Integer employeeId;
	@Column(name="firstName")
	private String firstName;
	@Column(name="lastName")
	private String lastName;
	@Column(name="designation")
	private String designation;
	@Column(name="grade")
	private Character grade;
	@Column(name="password")
	private String password;
	@Column(name="emailId")
	private String emailId;
	@Column(name="startDate")
	private Date startDate;
	@Column(name="endDate")
	private Date enddate;
	@Column(name="empStatus")
	private String empStatus;
	@Column(name="employeeType")
	private String employeeType;
	
//*******************************************************	
	@OneToOne
	@JoinColumn(name="timesheet_id")
	@JsonManagedReference
	private Timesheet timesheet;
//*******************************************************
	@ManyToOne
	@JoinColumn(name = "did_FK")
	private Deparment dept;
	
	public Deparment getDept() {
		return dept;
	}
	
	public void setDept(Deparment dept) {
		this.dept = dept;
	}
	
//**************************************************************************************	
	@ManyToOne
	@JoinColumn(name = "pid_FK")
	private ProjectDetails proj;
	
	public ProjectDetails getProj() {
		return proj;
	}
	
	public void setProj(ProjectDetails proj) {
		this.proj = proj;
	
//*********************************************************************************
	
	}

	public EmployeeDetails() {}
	

public EmployeeDetails(Integer employeeId, String firstName, String lastName, String designation, Character grade,
			String password, String emailId, Date startDate, Date enddate, String empStatus, String employeeType,
			Timesheet timesheet, Deparment dept,Set<ProjectDetails> projects) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.designation = designation;
		this.grade = grade;
		this.password = password;
		this.emailId = emailId;
		this.startDate = startDate;
		this.enddate = enddate;
		this.empStatus = empStatus;
		this.employeeType = employeeType;
		this.timesheet = timesheet;
		this.dept = dept;
	}



	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Character getGrade() {
		return grade;
	}

	public void setGrade(Character grade) {
		this.grade = grade;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEnddate() {
		return enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

	public String getEmpStatus() {
		return empStatus;
	}

	public void setEmpStatus(String empStatus) {
		this.empStatus = empStatus;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}

	
	public Timesheet getTimesheet() {
		return timesheet;
	}
	
	
	public void setTimesheet(Timesheet timesheet) {
		this.timesheet = timesheet;
	}


//	public Set<ProjectDetails> getProjects() {
//		return projects;
//	}
//
//
//	public void setProjects(Set<ProjectDetails> projects) {
//		this.projects = projects;
//	}


	@Override
	public String toString() {
		return "EmployeeDetails [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", designation=" + designation + ", grade=" + grade + ", password=" + password + ", emailId="
				+ emailId + ", startDate=" + startDate + ", enddate=" + enddate + ", empStatus=" + empStatus
				+ ", employeeType=" + employeeType + ", timesheet=" + timesheet + "]";
	}
	
	
	
}
