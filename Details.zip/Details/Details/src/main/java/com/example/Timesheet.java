package com.example;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name ="timesheet")
public class Timesheet {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int timesheet_id;

	@Column(name = "date")
	private String date;

	@Column(name = "working_hours")
	private String workingHours;

	@Column(name = "overtime")
	private String overtime;

	@Column(name = "leave_type")
	private String leavetype;
	
//********************************************************************************
	@OneToOne(mappedBy="timesheet")
	@JsonBackReference
	private EmployeeDetails employeedetails;
//********************************************************************************

	public Timesheet() {}
	public Timesheet(int timesheet_id, String date, String workingHours, String overtime, String leavetype,
			EmployeeDetails employeedetails) {
		super();
		this.timesheet_id = timesheet_id;
		this.date = date;
		this.workingHours = workingHours;
		this.overtime = overtime;
		this.leavetype = leavetype;
		this.employeedetails = employeedetails;
	}
	

	public int getTimesheet_id() {
		return timesheet_id;
	}


	public void setTimesheet_id(int timesheet_id) {
		this.timesheet_id = timesheet_id;
	}


	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getWorkingHours() {
		return workingHours;
	}

	public void setWorkingHours(String workingHours) {
		this.workingHours = workingHours;
	}

	public String getOvertime() {
		return overtime;
	}

	public void setOvertime(String overtime) {
		this.overtime = overtime;
	}

	public String getLeavetype() {
		return leavetype;
	}

	public void setLeavetype(String leavetype) {
		this.leavetype = leavetype;
	}

	public EmployeeDetails getEmployeedetails() {
		return employeedetails;
	}

	public void setEmployeedetails(EmployeeDetails employeedetails) {
		this.employeedetails = employeedetails;
	}
	@Override
	public String toString() {
		return "Timesheet [timesheet_id=" + timesheet_id + ", date=" + date + ", workingHours=" + workingHours
				+ ", overtime=" + overtime + ", leavetype=" + leavetype + ", employeedetails=" + employeedetails + "]";
	}	

}
