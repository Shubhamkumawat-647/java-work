package com.example;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/projectdetails")
public class ProjectDetailsController {

	@Autowired
	ProjectDetailsService projectDetailsService;
	
	@GetMapping("/getall")
	public List<ProjectDetails> getAllProjectDetails() throws ParseException {
		return projectDetailsService.getAllProjectDetails();
	
	}
	@GetMapping(path ={"/get/v1"} )
	public Integer getallprojectcount() throws ParseException{
	    return projectDetailsService.getallprojectcount();
	}
	
	@PostMapping("/post")
	public ResponseEntity<String> addProjectDetails(@RequestBody ProjectDetails projectDetails) throws ParseException{
		String emp=projectDetailsService.addProjectDetails(projectDetails);
		return new ResponseEntity<String>(emp,HttpStatus.OK);
		
	}
	
	@GetMapping("/get")
	public ProjectDetails getProjectDetails(@RequestParam Integer project_Id) throws ParseException{
		return projectDetailsService.getProjectDetails(project_Id);
	}
	
	@PutMapping("/update")
	public String updateProjectDetails(@RequestParam Integer employee_Id,@RequestBody ProjectDetails projectDetails) throws ParseException{
		return projectDetailsService.updateProjectDetails(employee_Id, projectDetails);
	}
	
	@DeleteMapping("/delete")
	public String deleteProjectDetails(@RequestParam Integer employee_Id) throws ParseException{
		return projectDetailsService.deleteProjectDetails(employee_Id);
	}
	
	@GetMapping(path = {"/get/v2"})
	public  Integer FindAllQuery() {
	    return projectDetailsService.FindAllQuery();
	}
}
